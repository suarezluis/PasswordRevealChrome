# PasswordRevealChrome
Chrome extension to reveal saved passwords
